# Deploying Dayflow on Cloudflare (Git repository)

## Folder layout (must be at the TOP of your repository)
```
wrangler.jsonc      <- tells Cloudflare how to deploy
src/worker.js       <- the server code (timetable reader + Ask Dayflow)
public/             <- the website files (index.html, icons, sw.js ...)
```
If your repository shows a single folder when you open it, the files are one level too deep. `wrangler.jsonc` must be visible right at the top.

## Steps
1. Put these files in a GitHub/GitLab repository and push.
2. Cloudflare dashboard > Workers & Pages > Create > Import a repository.
3. Build settings: leave "Build command" EMPTY. Deploy command: `npx wrangler deploy` (the default).
4. The Worker name in Cloudflare must match `"name"` in `wrangler.jsonc`. Either change `"name"` in the file to match, or rename the project. A mismatch makes the build fail.
5. After the first deploy: open the Worker > Settings > Variables and Secrets > Add > type **Secret**, name `ANTHROPIC_API_KEY`, paste your key. (Do NOT put it under Build variables.) Then deploy once more.
6. Optional: `ANTHROPIC_MODEL` (timetable model) and `ANTHROPIC_CHAT_MODEL` (Ask tab model, for example a cheaper one).
7. Check: open `https://YOUR-SITE/api/ask` in a browser. You should see `"configured":true`.

Tip: add a rate-limiting rule on `/api/*` in Cloudflare so nobody can run up your API bill.
