// Dayflow settings. Edit this file, then upload the folder again.
// If supabaseUrl and supabaseAnonKey stay empty, Dayflow works WITHOUT a sign-in screen
// and keeps everything in the visitor's own browser.
window.DAYFLOW_CONFIG = {
  supabaseUrl: "",      // for example: https://abcdxyz.supabase.co
  supabaseAnonKey: "",  // the long "anon" public key. NEVER paste the service_role key.
  resetUrl: "",         // your site address plus /reset-password.html, for example https://dayflow.pages.dev/reset-password.html
  privacyUrl: "privacy-policy.html"
};
